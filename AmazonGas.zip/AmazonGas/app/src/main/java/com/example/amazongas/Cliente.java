package com.example.amazongas;

public class Cliente {
    private int id;
    private String razaosocial;
    private String cnpj;

    public Cliente(){
        super();
    }

    public Cliente(int id, String razaosocial, String cnpj){
        super();
        this.id = id;
        this.razaosocial = razaosocial;
        this.cnpj = cnpj;
    }

    public int getId() {
        return id;
    }

    public String getCnpj() {
        return cnpj;
    }

    public String getRazaosocial() {
        return razaosocial;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setRazaosocial(String razaosocial) {
        this.razaosocial = razaosocial;
    }
}
