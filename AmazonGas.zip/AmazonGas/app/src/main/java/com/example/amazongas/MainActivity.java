package com.example.amazongas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView textView = (TextView) findViewById(R.id.text);
        final FloatingActionButton botaoAdd = findViewById(R.id.button_add);

        // Instacia a RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="https://my-json-server.typicode.com/felipesantosIroh/jsontest/db";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("cliente");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject cliente = jsonArray.getJSONObject(i);

                                int id = cliente.getInt("Id");
                                String razaoSocial = cliente.getString("RazaoSocial");
                                String cnpj = cliente.getString("CNPJ");

                                textView.append(razaoSocial + ", " + String.valueOf(id) + ", " + cnpj + "\n\n");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            textView.setText("Erro: " + e);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                textView.setText("Erro: " + error);
            }
        });

        queue.add(request);

        //botao abre activity para cadastrar
        botaoAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), Cadastrar.class);
                view.getContext().startActivity(intent);
            }
        });
    }


}